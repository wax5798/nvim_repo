-- Copyright (c) 2020-2021 hoob3rt
-- MIT license, see LICENSE for more details.
local get_mode = require('lualine.utils.mode').get_mode
return get_mode
