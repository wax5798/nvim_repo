#! /bin/sh

nvim --headless -c "PlenaryBustedDirectory ../lua/tests {minimal_init = '../lua/tests/minimal_init.vim'}"
