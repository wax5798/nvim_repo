// https://github.com/nvim-treesitter/nvim-treesitter/issues/2369
package main

import "fmt"

func new_line() {
	fmt.Println("Hello, World!")
}
