const char *a = "hello \
world";

const char *b = "hello "
    "world";
