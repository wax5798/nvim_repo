return require("plenary.log").new {
  plugin = "telescope",
  level = "info",
}
