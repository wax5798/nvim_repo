const abc = {};
// hl       11
// prettier-ignore
function MyComponent() {
    // hl           11 1
    return (
    // hl  2
        <div>
            <span>Hello world</span>
            <img src="self closing" />
        </div>
     );
// hl2
     }
// hl1
