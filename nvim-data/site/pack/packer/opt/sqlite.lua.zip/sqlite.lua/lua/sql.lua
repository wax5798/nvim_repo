---TODO: add deprecation warning after open pr in a number of repos depending on sql namespace
print "DEPRECATED: use require'sqlite' instead"
return require "sqlite.db"
