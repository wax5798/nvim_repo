run with one of these (in order of preference)
- `nvim --clean -u debug/min-alpha-dashboard.lua`
- `nvim --clean -u debug/min-alpha-startify.lua`
- `nvim --noplugin -u debug/min-alpha-dashboard.lua`
- `nvim --noplugin -u debug/min-alpha-startify.lua`
- `nvim -u debug/min-alpha-dashboard.lua`
- `nvim -u debug/min-alpha-startify.lua`
