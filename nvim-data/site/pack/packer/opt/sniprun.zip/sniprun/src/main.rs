fn main() {
    sniprun::start();
}
