#!/bin/bash
cat $1 > $2
