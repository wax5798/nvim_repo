#!/bin/bash
/bin/cat $1 > $2
