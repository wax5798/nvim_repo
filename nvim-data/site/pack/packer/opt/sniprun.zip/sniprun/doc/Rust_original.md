a custom compiler can be specified :

```
require'sniprun'.setup({
    interpreter_options = {
        Rust_original = {
             compiler = "rustc"
             }
        }
    }
})
```


