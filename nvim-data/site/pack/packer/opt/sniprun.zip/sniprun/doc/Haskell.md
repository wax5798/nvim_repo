# Haskell_original

require the 'ghc' compiler and the base libraries such as haskell-base-prelude
