Requires 'ts-node'

`sudo npm install -g ts-node typescript`

