---
name: Support for <language>
about: 'Adding an interpreter for <language> '
title: ''
labels: new-langage-support
assignees: ''

---

**Describe the language you want support for (compiler, specificities)**
I'd like an interpreter for <language> that uses <compiler/interpreter> [and that work with detected filetypes x,y and z]...

**Support Level to achieve**
X-level support is enough for me....

**Additional context**
Add any other context or screenshots about the feature request here.
