
import React, { useCallback, useEffect } from 'react'

const SamplePage: React.FC = () => {
  const [state, setstate] = useState<string>(initialState)


  return (
    <div className="h-full">












    </div>
  )
}

export default SamplePage
