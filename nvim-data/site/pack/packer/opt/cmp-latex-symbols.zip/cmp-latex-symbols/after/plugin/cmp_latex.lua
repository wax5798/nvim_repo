require("cmp").register_source("latex_symbols", require("cmp_latex_symbols").new())
