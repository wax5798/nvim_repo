describe '#foo' do
  context 'when foo' do
    it 'bars' do
     expect(1).to eq(1)
    end
  end
end
