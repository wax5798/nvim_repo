package.loaded['nord'] = nil
package.loaded['nord.colors'] = nil
package.loaded['nord.named_colors'] = nil
package.loaded['nord.theme'] = nil
package.loaded['nord.util'] = nil

require('nord').set()
