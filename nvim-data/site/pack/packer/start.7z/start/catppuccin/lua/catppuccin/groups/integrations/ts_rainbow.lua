local M = {}

function M.get()
	return {
		rainbowcol1 = { fg = C.red },
		rainbowcol2 = { fg = C.teal },
		rainbowcol3 = { fg = C.yellow },
		rainbowcol4 = { fg = C.blue },
		rainbowcol5 = { fg = C.pink },
		rainbowcol6 = { fg = C.flamingo },
		rainbowcol7 = { fg = C.green },
	}
end

return M
