return require "catppuccin.utils.lualine" "frappe"
