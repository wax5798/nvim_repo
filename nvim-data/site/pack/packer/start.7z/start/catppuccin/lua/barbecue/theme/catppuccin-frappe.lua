return require "catppuccin.utils.barbecue" "frappe"
