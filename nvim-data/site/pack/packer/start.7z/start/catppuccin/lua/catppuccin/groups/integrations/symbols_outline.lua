local M = {}

function M.get()
	return {
		FocusedSymbol = { fg = C.yellow, bg = C.none },
	}
end

return M
