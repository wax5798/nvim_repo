local M = {}

function M.get()
	return {
		Sneak = { fg = C.overlay2, bg = C.pink },
		SneakScope = { bg = C.text },
	}
end

return M
