return require "catppuccin.utils.lualine" "mocha"
