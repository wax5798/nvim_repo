Changelog
======================

2021-07-10 - Add hook function to be called before reading `commentstring`
2021-02-16 - Fix issue with `gv` causing entire buffer range to be acted on
2021-02-12 - Fix issue with motion acting on last visual selection
