local M = {}

function M.get()
	return {
		rainbowcol1 = { fg = cp.red },
		rainbowcol2 = { fg = cp.teal },
		rainbowcol3 = { fg = cp.yellow },
		rainbowcol4 = { fg = cp.blue },
		rainbowcol5 = { fg = cp.pink },
		rainbowcol6 = { fg = cp.flamingo },
		rainbowcol7 = { fg = cp.green },
	}
end

return M
