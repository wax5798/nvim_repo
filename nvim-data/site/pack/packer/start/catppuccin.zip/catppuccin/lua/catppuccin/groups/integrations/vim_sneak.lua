local M = {}

function M.get()
	return {
		Sneak = { fg = cp.overlay2, bg = cp.pink },
		SneakScope = { bg = cp.text },
	}
end

return M
