local M = {}

function M.get()
	return {
		FernBranchText = { fg = cp.blue },
	}
end

return M
