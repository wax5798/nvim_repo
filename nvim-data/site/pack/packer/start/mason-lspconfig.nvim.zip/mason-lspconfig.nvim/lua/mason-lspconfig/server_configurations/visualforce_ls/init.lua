return function()
    return {
        cmd = { "visualforce-language-server", "--stdio" },
    }
end
