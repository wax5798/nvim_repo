return function()
    return {
        cmd = { "psalm-language-server" },
    }
end
